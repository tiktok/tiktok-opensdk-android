# 安卓接入指南
注：本文为抖音短视频 Android终端SDK新手使用教程，只涉及SDK的使用方法，默认读者已经具有使用Android Studio开发Android程序的经验，以及相关的编程知识基础等。

##通用流程

### Requirements
* SDK最低支持：Android API 16 - 4.1.x版本

### 第一步：向抖音短视频申请你的clientkey
> 请到[开发者应用登记页面]()进行申请，申请后将获得clientkey, 之后通过clientkey为应用申请相关的权限，如分享；审核通过后即可使用相关的功能;

### 第二步：下载Android Demo
点击下载 [抖音短视频授权Demo]()。

“抖音短视频授权DEMO”提供了完整的工程配置及接入代码，你只需将其中的clientkey替换为你申请的clientkey，将local.properties中的sdk.dir配置为你的运行环境sdk位置，即可体验功能。

### 第三步：集成到开发环境

1. 下载[抖音短视频授权sdk]()
2. 将下载的sdk aar文件拷贝到app/libs目录下
3. 在app的build.gradle文件中引入该aar

```
repositories {
    flatDir {
        dirs 'libs'
    }
}

dependencies {
    compile(name:'aweme-open-sdk', ext:'aar')
}
```
至此，sdk开发环境配置完毕.