##抖音授权接入
1.在Application中，初始化TTOpenApiFactory

```
String clientkey = "XXXXX"; // 修改为在开发者应用登记页面申请的clientkey
TTOpenApiFactory.init(new BDOpenConfig(clientkey));
```

2.请求授权

```
SendAuth.Request request = new SendAuth.Request();
request.scope = "user_info";                             // 用户授权时必选权限
request.state = "ww";                                    // 用于保持请求和回调的状态，授权请求后原样带回给第三方。
TTOpenApi ttOpenApi= TTOpenApiFactory.create(this);
ttOpenApi.sendAuthLogin(request); //请求授权。如果没有安装应用。使用h5页面授权
```

3.接受返回信息

> 包名下创建bdopen.BdEntryActivity，初始化TTOpenApi，实现BDApiEventHandler接口，在onResp方法中回调授权结果。

```
public class BdEntryActivity extends Activity implements BDApiEventHandler {

    TTOpenApi ttOpenApi;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ttOpenApi= TTOpenApiFactory.create(this);
        ttOpenApi.handleIntent(getIntent(),this);
    }

    @Override
    public void onResp(BaseResp resp) {
        // 授权成功可以获得authCode
        SendAuth.Response response = (SendAuth.Response) resp;
        log("authCode " + response.authCode);        
    }
}
```

4.Manifest中注册

```
 <uses-permission android:name="android.permission.INTERNET" />
```

```
<activity
    android:name=".bdopen.BdEntryActivity"
    android:exported="true">
</activity>
```

## 常见问题
1. 内嵌到其他app的sdk接入时，为什么在包名下创建bdopen.BdEntryActivity不会被吊起？
    答：请求授权时，​request.callerLocalEntry​设置接收回调类的全路径名。
2. 为什么接入授权sdk后，网页授权界面空白？
   答：抖音的授权页面使用https，你需要配置你的网络接受https的证书。可以像demo manifest文件中，通过android:networkSecurityConfig设置。
