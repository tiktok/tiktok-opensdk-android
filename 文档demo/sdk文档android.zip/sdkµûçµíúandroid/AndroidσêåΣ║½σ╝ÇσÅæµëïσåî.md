#抖音分享功能

抖音分享是指第三方App通过接入该功能，让用户可以从App分享信息到抖音。目前支持的内容格式为单图、多图、单视频及多视频；调用分享功能后分别进入的页面如下:

单图：分享后进入抖音照片编辑页；

多图：分享后进入抖音动画编辑页；

单视频：分享后进入抖音视频编辑页；

多视频：分享到进入抖音多视频编辑页;


* 注：eclipse版本暂未完全支持，需要用分享功能的可去资源下载页下载sdk包（aar格式），从中解压出jar包并导入自己的工程中;
* 支持分享的最低抖音版本为5.2.0;

### 接入步骤
1. 在Application中，初始化TTOpenApiFactory

```
String clientkey = "XXXXX"; // 修改为在开发者应用登记页面申请的clientkey
TTOpenApiFactory.init(new BDOpenConfig(clientkey));
```

2. Manifest中注册

```
 <uses-permission android:name="android.permission.INTERNET" />
```
```
<activity
    android:name=".bdopen.BdEntryActivity"
    android:exported="true">
</activity>
```

3. 分享图片或视频

```
// 初始化bdOpenApi
TTOpenApi bdOpenApi;
bdOpenApi = TTOpenApiFactory.create(this);

// 初始化资源路径，路径请提供绝对路径.demo里有获取绝对路径的util代码
ArrayList<String> mUri = new ArrayList<>();
mUri.add ...

// 分享图片到抖音
DYImageObject imageObject = new DYImageObject();
imageObject.mImagePaths = mUri;
DYMediaContent mediaContent = new DYMediaContent();
mediaContent.mMediaObject = imageObject;
request.mMediaContent = mediaContent;
request.mState = "ww";
bdOpenApi.share(request);

// 分享视频到抖音
DYVideoObject videoObject = new DYVideoObject();
videoObject.mVideoPaths = mUri;
DYMediaContent content = new DYMediaContent();
content.mMediaObject = videoObject;
request.mMediaContent = content;
request.mState = "ss";
bdOpenApi.share(request);

```

4. 接受返回信息

> 包名下创建bdopen.BdEntryActivity，初始化TTOpenApi，实现BDApiEventHandler接口，在onResp方法中回调授权结果。

```
public class BdEntryActivity extends Activity implements BDApiEventHandler {

    TTOpenApi ttOpenApi;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ttOpenApi= TTOpenApiFactory.create(this);

        //share使用handleShareIntent
        ttOpenApi.handleShareIntent(getIntent(), this);
    }

    @Override
    public void onReq(BaseReq req) {

    }

    @Override
    public void onResp(BaseResp resp) {
        if (resp.getType() == DYOpenConstants.ModeType.SHARE_CONTENT_TO_DY_RESP) {
            Share.Response response = (Share.Response) resp;
            // errorcode在DYOpenConstants中定义
            Toast.makeText(this, response.errorCode + "", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onErrorIntent(@Nullable Intent intent) {
        // 错误数据
    }
}
```